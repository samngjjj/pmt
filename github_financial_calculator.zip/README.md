# Pro 動態財務分析儀表板 (Dynamic Financial Calculator)

![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=flat&logo=html5&logoColor=white)
![TailwindCSS](https://img.shields.io/badge/Tailwind_CSS-38B2AC?style=flat&logo=tailwind-css&logoColor=white)
![Chart.js](https://img.shields.io/badge/Chart.js-FF6384?style=flat&logo=chartdotjs&logoColor=white)

這是一個專業級的單頁式動態財務分析儀表板 (TVM Calculator)，支援計算現值 (PV)、終值 (FV) 與每期金流 (PMT)，並具備動態表格與視覺化圖表功能。

## ✨ 功能特色 (Features)
*   **智慧求解器**: 留空任一參數 (PV, FV, PMT)，系統會自動推導計算。
*   **動態視覺化**: 整合 Chart.js，即時繪製資產/負債演進曲線 (Glassmorphism 漸層風格)。
*   **攤還明細表**: 自動生成最高 360 期的本息攤還明細與資產累積表。
*   **情境預設**: 內建「房貸試算」與「定時定額儲蓄」快速按鈕。
*   **現代化 UI**: 使用 Tailwind CSS 打造 Dark Mode 玻璃擬物化 (Glassmorphism) 介面。

## 🚀 部署至 GitHub Pages (Deployment)
本專案由純 HTML, CSS (Tailwind CDN) 與 JavaScript (Chart.js CDN) 構成，完全無需後端伺服器即可運行。您可以直接將其託管在 GitHub Pages 上：

### 部署步驟：
1. 註冊並登入 [GitHub](https://github.com/)。
2. 點擊右上角的 `+` 建立一個新的 Repository（例如命名為 `financial-calculator`）。
3. 將本專案 ZIP 檔解壓縮，把裡面的 `index.html` 與 `README.md` 上傳到該 Repository。
4. 進入該 Repository 的 **Settings** > 側邊欄的 **Pages**。
5. 在 **Build and deployment** 區塊下的 **Source** 選擇 `Deploy from a branch`。
6. 在 **Branch** 下拉選單選擇 `main` (或 `master`)，資料夾保持 `/ (root)`，然後點擊 **Save**。
7. 等待約 1~2 分鐘，GitHub 會在該頁面上方顯示您的專屬網址，點擊即可在線上瀏覽您的動態財務分析儀表板！
